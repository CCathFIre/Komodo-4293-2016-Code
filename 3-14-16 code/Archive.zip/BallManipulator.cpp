#include "BallManipulator.h"
#include "WPILib.h"
#include "Definitions.h"



// DO NOT CALL
BallManipulator::BallManipulator()
	: openSwitch(0),
	  closeSwitch(0),
	  liftMotor(0),
	  pinchMotor(0)
{

}

BallManipulator::BallManipulator(unsigned int lift, unsigned int pinch, unsigned int open, unsigned int close, Encoder &eEncoder)
	: openSwitch(open),
	  closeSwitch(close),
	  liftMotor(lift),
	  pinchMotor(pinch),
	  ballManipulatorEncoder(&eEncoder)
{
	ballManipulatorEncoder->Reset();
	pinchSpeed = B_MANIPULATOR_PINCH_SPEED;
	pinchDirection = false; //When the robot starts, the pinchers should be closing.
	openFlag = false;
	closeFlag = false;

}



////////////////////////////////////////
/////////////   Divider!   /////////////
////////////////////////////////////////



// Sets the lifter to go up
void BallManipulator::Tilt(float speed) {
	liftMotor.SetSpeed(speed);
}


void BallManipulator::Pinch() {
	if(openSwitch.GetValue() > ONE_THRESHOLD){
		openFlag = true;
	}
	else if(openSwitch.GetValue() < ZERO_THRESHOLD)
	{
		openFlag = false;
	}

	if(closeSwitch.GetValue() > ONE_THRESHOLD){
		closeFlag = true;
	}
	else if(closeSwitch.GetValue() < ZERO_THRESHOLD)
	{
		closeFlag = false;
	}
//The above two if loops map the analog values of the two switches to digital logic

	if(pinchDirection && !openFlag){ //Open the pinchers
	pinchMotor.SetSpeed(-pinchSpeed);
	}
	else if(!pinchDirection && !closeFlag){//Close the pinchers
	pinchMotor.SetSpeed(pinchSpeed);
	}
	else{
	StopPinch();
	}

}


void BallManipulator::StopTilt() {
	liftMotor.SetSpeed(0);

}

void BallManipulator::StopPinch() {
	pinchMotor.SetSpeed(0);

}

void BallManipulator::TempPinch(float speed){ //TEMP FUNCTION! REMOVE THIS WHEN LIMIT SWITCHES HAVE BEEN ATTACHED!!!
	pinchMotor.SetSpeed(speed);
}

