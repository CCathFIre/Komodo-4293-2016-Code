#include "BallManipulator.h"
#include "WPILib.h"
#include "Definitions.h"



// DO NOT CALL
BallManipulator::BallManipulator()
	: openSwitch(0),
	  liftMotor(0),
	  pinchMotor(0)
{

}

BallManipulator::BallManipulator(unsigned int lift, unsigned int pinch, unsigned int open, Encoder &eEncoder)
	: openSwitch(open),
	  liftMotor(lift),
	  pinchMotor(pinch),
	  ballManipulatorEncoder(&eEncoder)
{
	ballManipulatorEncoder->Reset();
	pinchSpeed = B_MANIPULATOR_PINCH_SPEED;
	pinchDirection = true; //When the robot starts, the pinchers MUST be trying to open. Otherwise, it will run the "close" code.
	counter = 0;
}



////////////////////////////////////////
/////////////   Divider!   /////////////
////////////////////////////////////////



// Sets the lifter to go up
void BallManipulator::Tilt(float speed) {
liftMotor.SetSpeed(speed); /*
	if(fabs(speed) > GAMEPAD_STANDARD_DRIFT)
		liftMotor.SetSpeed(speed);
	else if(fabs(ballManipulatorEncoder->GetRate()) > B_MANIPULATOR_DRIFT_THRESHOLD) {
		liftMotor.SetSpeed(-ballManipulatorEncoder->GetRate()*B_MANIPULATOR_DRIFT_CORRECT);
	}
	else{
		liftMotor.SetSpeed(0);
	} */

}


void BallManipulator::Pinch() {

	if(pinchDirection && openSwitch.GetValue() < OPEN_THRESHOLD){ //Open the pinchers
	pinchMotor.SetSpeed(-pinchSpeed);
	}
	else if(!pinchDirection && counter < PINCHER_TIME_CONSTANT){//Close the pinchers
	pinchMotor.SetSpeed(pinchSpeed);
	counter ++;
	}
	else{
	StopPinch();
	}

}


void BallManipulator::StopTilt() {
	liftMotor.SetSpeed(0);

}

void BallManipulator::StopPinch() {
	pinchMotor.SetSpeed(0);

}

void BallManipulator::TempPinch(float speed){ //TEMP FUNCTION! REMOVE THIS WHEN LIMIT SWITCHES HAVE BEEN ATTACHED!!!
	pinchMotor.SetSpeed(speed);
}

