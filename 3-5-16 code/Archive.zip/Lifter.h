/*
 * Lifter.h
 *
 *  Created on: Jan 30, 2016
 *      Author: Alex
 */

#ifndef SRC_LIFTER_H_
#define SRC_LIFTER_H_

#include "Definitions.h"
#include "WPILib.h"



//
class Lifter {
public:
	// Our constructor classes
	Lifter();	// DO NOT CALL
	Lifter(unsigned int victorLift, unsigned int victorTilt, Encoder &eEncoder);

	// Classes to manually make the lifter go up or down
	void Lift(float speed); // Attached to the left and right triggers
	void LiftUp();
	void LiftDown();

	void Tilt(float speed);     // Tilt from gamepad stick
	void TiltUp();   // Manual up tilt
	void TiltDown(); // Manual down tilt

	void StopLift();
	void StopTilt();
	void StopAll();

private:
	Victor liftMotor, tiltMotor;
	Encoder *lifterEncoder;
};



#endif /* SRC_LIFTER_H_ */
