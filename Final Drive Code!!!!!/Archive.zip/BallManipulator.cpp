#include "BallManipulator.h"
#include "WPILib.h"
#include "Definitions.h"

BallManipulator::BallManipulator()
	: openSwitch(0),
	  liftMotor(0),
	  pinchMotor(0)
{

}

BallManipulator::BallManipulator(unsigned int lift, unsigned int pinch, unsigned int open, Encoder &eEncoder)
	: openSwitch(open),
	  liftMotor(lift),
	  pinchMotor(pinch),
	  ballManipulatorEncoder(&eEncoder)
{
	ballManipulatorEncoder->Reset();
	pinchSpeed = B_MANIPULATOR_PINCH_SPEED;
	pinchDirection = false;
	pinchCounter = 0;
	driftCenter = 0;
	driftFlag = false;
	started = false;
	tiltCounter = 0;
	direction = 1;
	canTilt = true;
}

void BallManipulator::Tilt(float speed) {

	if(speed > 0 && pinchDirection == true && ballManipulatorEncoder->GetRaw() > B_MANIPULATOR_ENC_BALL)
		canTilt = false;
	else if(speed < 0 && pinchDirection == true && ballManipulatorEncoder->GetRaw() < B_MANIPULATOR_ENC_OPENSTOP)
		canTilt = false;
	else if(speed > 0 && ballManipulatorEncoder->GetRaw() > B_MANIPULATOR_ENC_MAX + 50)
		canTilt = false;
	else
		canTilt = true;

	if(fabs(speed) > GAMEPAD_STANDARD_DRIFT) {
		if(canTilt){
		liftMotor.SetSpeed(speed);
		}

		driftFlag = false;
		tiltCounter = 0;
	}
	else if(tiltCounter > PINCHER_TIME_CONSTANT && driftFlag == false) {
		driftCenter = ballManipulatorEncoder->GetRaw();
		driftFlag = true;
	}
	else if (driftFlag == true) {
		if((ballManipulatorEncoder->GetRaw() - driftCenter) > B_MANIPULATOR_DRIFT_THRESHOLD)
			liftMotor.SetSpeed(-B_MANIPULATOR_ADJUST_SPEED);
		else if((ballManipulatorEncoder->GetRaw() - driftCenter) < -1*B_MANIPULATOR_DRIFT_THRESHOLD)
			liftMotor.SetSpeed(B_MANIPULATOR_ADJUST_SPEED);
		else
			liftMotor.SetSpeed(0);
	}
	else{
		liftMotor.SetSpeed(0);
	}
tiltCounter++;
}


void BallManipulator::Pinch() {
if(started){
	if(pinchDirection && openSwitch.GetValue() < OPEN_THRESHOLD){ //Open the pinchers
	pinchMotor.SetSpeed(direction*pinchSpeed);
	}
	else if(!pinchDirection && pinchCounter < PINCHER_TIME_CONSTANT){//Close the pinchers
	pinchMotor.SetSpeed(-direction*pinchSpeed);
	pinchCounter++;
	}
	else{
	StopPinch();
	}
}
}

void BallManipulator::StopTilt() {
	liftMotor.SetSpeed(0);
}

void BallManipulator::StopPinch() {
	pinchMotor.SetSpeed(0);
}
