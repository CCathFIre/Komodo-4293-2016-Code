#include "Lifter.h"
#include "WPILib.h"
#include "Definitions.h"

Lifter::Lifter()
	: liftMotor(0),
	  tiltMotor(0)
{
}

Lifter::Lifter(unsigned int jaguarLift, unsigned int jaguarTilt, Encoder &eEncoder)
	: liftMotor(jaguarLift),
	  tiltMotor(jaguarTilt),
	  lifterEncoder(&eEncoder)
{
	lifterEncoder->Reset();
	driftCenter = 0;
	driftFlag = false;
	tiltCounter = 0;
	canTilt = true;
}

void Lifter::ExtendRetract(float speed) {
	liftMotor.SetSpeed(speed*LIFTER_EXT_SCALE_FACTOR);
}

void Lifter::Tilt(float speed) {

	if(fabs(speed) > GAMEPAD_STANDARD_DRIFT) {
			if(canTilt){
			tiltMotor.SetSpeed(speed*LIFTER_TILT_SCALE_FACTOR);
			}

			driftFlag = false;
			tiltCounter = 0;
		}
		else if(tiltCounter > 4 && driftFlag == false) {
			driftCenter = lifterEncoder->GetRaw();
			driftFlag = true;
		}
		else if (driftFlag == true) {
			if((lifterEncoder->GetRaw() - driftCenter) > LIFTER_DRIFT_THRESHOLD)
				tiltMotor.SetSpeed(-LIFTER_ADJUST_SPEED);
			else if((lifterEncoder->GetRaw() - driftCenter) < -1*LIFTER_DRIFT_THRESHOLD)
				tiltMotor.SetSpeed(LIFTER_ADJUST_SPEED);
			else
				tiltMotor.SetSpeed(0);
		}
		else{
			tiltMotor.SetSpeed(0);
		}
	tiltCounter++;
}

void Lifter::StopAll() {
	liftMotor.SetSpeed(0);
	tiltMotor.SetSpeed(0);
}
