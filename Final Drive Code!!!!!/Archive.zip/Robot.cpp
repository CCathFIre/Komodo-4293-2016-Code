#include "WPILib.h"
#include "Definitions.h"
#include "Lifter.h"
#include "BallManipulator.h"



// Main robot class
class Robot: public IterativeRobot
{

	RobotDrive myRobot;
	LiveWindow *lw;
	int autoLoopCounter;

	Joystick rStick;
	Joystick lStick;
	Joystick gamePad;

	int driveOption;
	double joystickDifference;
	double joystickAverage;

	bool buttonDone[6];

	int autoOption;
	float extenderMap;

	Encoder encoder1; //Right drive motor
	Encoder encoder2; //Left drive motor

	Encoder encoderM; //Ball manipulator encoder
	Encoder encoderU; //Lifter encoder

	double autoTurn;

	Lifter lifter;
	BallManipulator ballManipulator;

	DigitalInput autoSwitch;



public:
	Robot() :
		myRobot(0, 1),
		rStick(RIGHT_JOYSTICK_INPUT_CHANNEL),
		lStick(LEFT_JOYSTICK_INPUT_CHANNEL),
		gamePad(GAMEPAD_INPUT_CHANNEL),
		lw(LiveWindow::GetInstance()),
		autoLoopCounter(0),
		encoder1(ENCODER_CHANNEL_RA, ENCODER_CHANNEL_RB),
		encoder2(ENCODER_CHANNEL_LA, ENCODER_CHANNEL_LB),
		encoderM(ENCODER_CHANNEL_MA, ENCODER_CHANNEL_MB),
		encoderU(ENCODER_CHANNEL_UA, ENCODER_CHANNEL_UB),
		lifter(LIFTER_CHANNEL_EXTEND, LIFTER_CHANNEL_TILT, encoderU),
		ballManipulator(B_MANIPULATOR_CHANNEL_LIFT, B_MANIPULATOR_CHANNEL_PINCH, OPEN_SWITCH, encoderM),
		autoSwitch(AUTO_SWITCH_CHANNEL)
	{
		myRobot.SetExpiration(0.1);
		driveOption = TANK;
		autoOption = LOW_BAR;
		autoTurn = 0;
		extenderMap = 0;

	}

private:
	void AutonomousInit();
	void AutonomousPeriodic();

	void TeleopInit();
	void TeleopPeriodic();

	void TestPeriodic();


	void DriverControl(int driveControl, float autoSpeed, float autoTurn);
	void ButtonControl();
	void AutoPortculis();

};


void Robot::AutonomousInit() {
	autoLoopCounter = 0;

	encoder1.Reset();
	encoder2.Reset();
	encoderU.Reset();
	encoderM.Reset();

	if(autoSwitch.Get())
		autoOption = ROUGH_TERRAIN;
	else
		autoOption = LOW_BAR;

}

void Robot::AutonomousPeriodic() {

	switch(autoOption){

	case ROUGH_TERRAIN:
	autoTurn = 0;
	if(encoderM.GetRaw() < B_MANIPULATOR_ENC_MAX)
		ballManipulator.Tilt(0.5);
	else
		ballManipulator.Tilt(0);
	if (encoder1.GetRaw() > -ONE_FOOT_RIGHT_ENCODER*10)
		DriverControl(AUTOBOT, -0.75, autoTurn);
	else
		DriverControl(AUTOBOT, 0, 0);
	break;


	case LOW_BAR:
		lifter.Tilt(-0.5);
	if(encoderM.GetRaw() > B_MANIPULATOR_ENC_BALL)
		ballManipulator.Tilt(-0.5);
	else
		ballManipulator.Tilt(0);

	autoTurn = 0;
	if (encoder1.GetRaw() > -ONE_FOOT_RIGHT_ENCODER*10)
		DriverControl(AUTOBOT, -0.75, autoTurn);
	else
		DriverControl(AUTOBOT, 0, 0);

	break;

	}

}



void Robot::TeleopInit() {

	driveOption = TANK;
	encoder1.Reset();
	encoder2.Reset();
	encoderM.Reset();
	encoderU.Reset();

	for(int c=0; c<7; c++)
		buttonDone[c] = false;

	CameraServer::GetInstance()->SetQuality(50);
	//the camera name (ex "cam0") can be found through the roborio web interface
	CameraServer::GetInstance()->StartAutomaticCapture("cam0");

}


void Robot::TeleopPeriodic() {

	//Right trigger extends, left trigger retracts
	if(gamePad.GetRawAxis(GAMEPAD_LEFT_TRIGGER) > GAMEPAD_STANDARD_DRIFT && gamePad.GetRawAxis(GAMEPAD_RIGHT_TRIGGER) > GAMEPAD_STANDARD_DRIFT)
		extenderMap = 0;
    else
		extenderMap = gamePad.GetRawAxis(GAMEPAD_RIGHT_TRIGGER) - gamePad.GetRawAxis(GAMEPAD_LEFT_TRIGGER);

	DriverControl(driveOption, 0, 0);
	ButtonControl();
	ballManipulator.Tilt(-B_MANIPULATOR_SCALE_FACTOR*gamePad.GetRawAxis(GAMEPAD_RIGHT_STICK_Y));
	ballManipulator.Pinch();
	lifter.Tilt(-gamePad.GetRawAxis(GAMEPAD_LEFT_STICK_Y));
	lifter.ExtendRetract(extenderMap);


}



void Robot::AutoPortculis() {

	encoder1.Reset();
	encoder2.Reset();
	while(encoderM.GetRaw() < B_MANIPULATOR_ENC_LIFT)
	{
		ballManipulator.Tilt(1);
		DriverControl(AUTOBOT, -0.55, 0);
	}
ballManipulator.Tilt(0);
Wait(0.5);
	while(encoder1.GetRaw() > -ONE_FOOT_RIGHT_ENCODER*2.5)
	{
		ballManipulator.Tilt(0);
		DriverControl(AUTOBOT, -0.75, 0);
	}

}


void Robot::ButtonControl() {

	if(gamePad.GetRawButton(GAMEPAD_BUTTON_A)== true && buttonDone[GAMEPAD_BUTTON_A]== false){
		buttonDone[GAMEPAD_BUTTON_A] = true;
		ballManipulator.pinchDirection = !ballManipulator.pinchDirection;
		ballManipulator.started = true;
		if(ballManipulator.pinchDirection == 0)
		ballManipulator.pinchCounter = 0;
	} else if(gamePad.GetRawButton(GAMEPAD_BUTTON_A) == false && buttonDone[GAMEPAD_BUTTON_A] == true){
		buttonDone[GAMEPAD_BUTTON_A] = false;
	}


	if(gamePad.GetRawButton(GAMEPAD_BUTTON_B)== true && buttonDone[GAMEPAD_BUTTON_B]== false){
		buttonDone[GAMEPAD_BUTTON_B] = true;

	} else if(gamePad.GetRawButton(GAMEPAD_BUTTON_B) == false && buttonDone[GAMEPAD_BUTTON_B] == true){
		buttonDone[GAMEPAD_BUTTON_B] = false;
	}


    if(gamePad.GetRawButton(GAMEPAD_BUTTON_X)== true && buttonDone[GAMEPAD_BUTTON_X]== false){
		buttonDone[GAMEPAD_BUTTON_X] = true;
		encoder1.Reset();
		encoder2.Reset();
	} else if(gamePad.GetRawButton(GAMEPAD_BUTTON_X) == false && buttonDone[GAMEPAD_BUTTON_X] == true){
		buttonDone[GAMEPAD_BUTTON_X] = false;
	}


	if(gamePad.GetRawButton(GAMEPAD_BUTTON_Y)== true && buttonDone[GAMEPAD_BUTTON_Y]== false){
		buttonDone[GAMEPAD_BUTTON_Y] = true;
		ballManipulator.direction = -1*ballManipulator.direction;
	} else if(gamePad.GetRawButton(GAMEPAD_BUTTON_Y) == false && buttonDone[GAMEPAD_BUTTON_Y] == true){
		buttonDone[GAMEPAD_BUTTON_Y] = false;
	}


}

void Robot::TestPeriodic() {
	lw->Run();
}


void Robot::DriverControl(int driveControl, float autoSpeed, float autoTurning) {
	switch (driveControl) {

	case TANK:
		joystickDifference = lStick.GetRawAxis(LEFT_STICK_Y) - rStick.GetRawAxis(RIGHT_STICK_Y);
		joystickAverage = (lStick.GetRawAxis(LEFT_STICK_Y) + rStick.GetRawAxis(RIGHT_STICK_Y))/2;

		if (fabs(joystickDifference) > TANK_TURN_THRESHOLD) {
			myRobot.TankDrive(rStick.GetRawAxis(RIGHT_STICK_Y), lStick.GetRawAxis(LEFT_STICK_Y));
		} else {
			myRobot.ArcadeDrive(joystickAverage, 0);
		}
		break;

	case AUTOBOT:
		if(autoTurning == 0){
			myRobot.ArcadeDrive(autoSpeed, 0);
		} else {
			myRobot.ArcadeDrive(autoSpeed, autoTurning);
		}
		break;
	}
}

START_ROBOT_CLASS(Robot)
