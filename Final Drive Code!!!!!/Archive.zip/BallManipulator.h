/*
 * BallManipulator.h
 *
 *  Created on: Jan 30, 2016
 *      Author: Alex
 */

#ifndef SRC_BALLMANIPULATOR_H_
#define SRC_BALLMANIPULATOR_H_

#include "Definitions.h"
#include "WPILib.h"


class BallManipulator {
public:

	BallManipulator();
	BallManipulator(unsigned int lift, unsigned int pinch, unsigned int open, Encoder &eEncoder);

	void Tilt(float speed);
	void Pinch();
	void StopTilt();
	void StopPinch();

	float pinchSpeed;
	bool pinchDirection;

	AnalogInput openSwitch;

	int pinchCounter;
	float driftCenter;
	bool driftFlag;
	int tiltCounter;
	bool started;
	int direction;
	bool canTilt;

private:
	VictorSP liftMotor;
	VictorSP pinchMotor;
	Encoder *ballManipulatorEncoder;
};

#endif /* SRC_BALLMANIPULATOR_H_ */
